package com.example.admin.signup;

/**
 * Created by Admin on 16-05-2020.
 */

public class ParkingData10 extends UserProfile {
    public String A01;

    public ParkingData10() {
    }
    public String getA01() {
        return A01;
    }

    public void setA01(String A01) {
        this.A01 = A01;
    }


}
