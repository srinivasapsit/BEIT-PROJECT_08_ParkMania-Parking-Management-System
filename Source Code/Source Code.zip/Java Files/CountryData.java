package com.example.admin.signup;

/**
 * Created by Admin on 09-04-2020.
 */
public class CountryData {
    public static final String[] countryNames = {"India"};

    public static final String[] countryAreaCodes = {"91"};
}
